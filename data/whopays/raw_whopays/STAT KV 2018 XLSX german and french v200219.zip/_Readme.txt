
(Deutsche Version folgt weiter)


PROBLEME A L'OUVERTURE DES FICHIERS
-----------------------------------
Si vous rencontrez des probl�mes � l'ouverture des fichiers extraits et qu'un message comme ci-dessou appara�t lors de l'ouverture d'un tableau Excel, cela signifie que la longueur totale du chemin et du nom du fichier, extension de nom du fichier comprise, comporte plus de 218 caract�res. Cette limitation inclut les trois caract�res repr�sentant le lecteur, les caract�res des noms de dossiers, la barre oblique inverse s�parant les noms de dossiers et les caract�res des noms de fichiers.

			"Nous n'avons pas pu ouvrir ce fichier. Veuillez lui attribuer un nom plus court ou copiez-le dans un autre dossier pour lequel le chemin d'acc�s est plus court" 


Solution: assurez-vous que le chemin du fichier ne contient pas trop de caract�res. Pour cela, appliquez l'une des m�thodes ci-dessous.

- Renommez le fichier en lui attribuant un nom plus court.
- Renommez un ou plusieurs dossiers contenant le fichier en leur attribuant �galement un nom plus court.
- D�placez le fichier vers un dossier ayant un nom de chemin d'acc�s plus court.



CONTENU DU DOSSIER EXTRAIT
--------------------------

Dans le dossier extrait, vous trouvez 

- Dossier "T 00 Beilage - Annexe" : fichiers d'annexes contenant les cl�s de passage des tableaux et des graphiques par rapport � l'ann�e pr�c�dente et depuis 1996. il met en �vidence les nouveaux tableaux et graphiques ainsi que les modifications, le cas �ch�ant.

- Dossier "T 01" � "T 10": ensemble des dossiers contenant les tableaux des chapitres 1 � 10 de la statistique de l'assurance-maladie obligatoire. Dans chacun de ces dossiers, le fichier KVy00.xlsx (y : 1 � 10) contient la liste des tableaux du chapitre y.

- Fichier d'aper�u des tableaux (Uebersicht_Tabellen - Aper�u_tableaux.xlsx): indique la date de mise en ligne des tableaux et les �ventuelles corrections. Dans la version 2017, il s'agissait du fichier "_Inhaltverzeichnis - Table des mati�res.xlsx". Les informations contenues sont les m�mes pour 2018. Seuls l'apparence et le nom du fichier ont chang�.

- La liste des tableaux "Liste der Tabellen YYYY - Liste des tableaux YYYY fd.xlsx" �num�re tous les tableaux par chapitre pour l'ann�e actuelle YYYY, en indiquant, le cas �ch�ant les nouveaux tableaux. 


****************************************************************************************************************************************************


PROBLEME BEIM �FFNEN DER DATEIEN
--------------------------------

Soll beim �ffnen der extrairten Excel--Tabelle eine �hnliche Meldung wie unten angezeigt, �bersteigt die Gesamtl�nge von Pfad und Dateiname einschlie�lich der Dateinamenerweiterung 218 Zeichen. 
Diese Einschr�nkung betrifft die drei Zeichen f�r das Laufwerk, die Zeichen in den Ordnernamen, den umgekehrten Schr�gstrich zwischen den Ordnernamen und die Zeichen im Dateinamen:


			"Wir konnten diese Datei nicht �ffnen, geben Sie ihr einen k�rzeren Namen oder kopieren Sie sie in einen anderen Ordner, f�r den der Pfad k�rzer ist" 


Abhilfe: Stellen Sie sicher, dass der Dateipfad nicht mehr Zeichen enth�lt als erlaubt. Wenden Sie hierzu eine der folgenden Methoden an.

- Benennen Sie die Datei um, sodass ihr Name k�rzer ist.
- Benennen Sie einen oder mehrere Ordner, die die Datei enthalten, so um, dass ihre Namen k�rzer sind.
- Verschieben Sie die Datei in einen Ordner mit einem k�rzeren Pfadnamen.



INHALT DES EXTRAIERTEN DOSSIERS
-------------------------------

Im extraierten Dossier finden Sie:

- Dossier "T 00 Beilage - Annexe" : Beilage f�r �bergangsschl�ssel Tabellen und Grafiken gegen�ber dem Vorjahr und ab 1996. Zeigt die neuen Tabellen und grafiken sowie die �nderungen gegebenenfals.

- Dossier "T 01" bis "T 10": Gesamtzahl von Dossiers mit Tabellen der Kapitel 1 bis 10 der Statistik der obligatorischen Krankenversicherung. In jedem Dossier ist die Datei KVy00.xlsx (y : 1 bis 10) vorhanden, welche die Liste der Tabellen des entsprechenden Kapitels (y) enth�lt.

- �bersichtstabellen-Datei (Uebersicht_Tabellen - Aper�u_tableaux.xlsx): gibt das Aufschaltungsdatum der Tabellen auf Internet und die eventuellen Korrekturen an. Im 2017 handelte es sich um die  Datei "_Inhaltverzeichnis - Table des mati�res.xlsx". Die enthaltenen Informationen sind in der Version 2018 gleich geblieben. Lediglich ist die Formtierung und der Dateinamen neu.

- Die Tabellen-Liste "Liste der Tabellen YYYY - Liste des tableaux YYYY fd.xlsx" listet alle Tabellen in den jeweiligen Kapitel f�r das aktuelle Datenjahr YYYY auf und zeigt die neuen Tabellen gegebenenfalls.